/**
 * Transaction.js
 *
 * @description :: A model definition represents a database table/collection.
 * @docs        :: https://sailsjs.com/docs/concepts/models-and-orm/models
 */

module.exports = {
  attributes: {
    transDate: {
      type: 'string',
      required: true,
    },
    transName: {
      type: 'string',
      required: true,
    },
    amount: {
      type: 'number',
      required: true,
      min: 0,
    },
    type: {
      type: 'string',
      isIn: ['income', 'expense'],
      required: true,
    },
    description: {
      type: 'string',
    },

    // associations
    accountId: {
      model: 'account',
    },
    userId: {
      model: 'user',
    },
  },
};
